package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.jar.Attributes;

public class Register extends AppCompatActivity {

    EditText name, num;
    Button Reg;
    TextView lbtn;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);


        name = findViewById(R.id.name);
        num = findViewById(R.id.num);


        Reg = findViewById(R.id.Reg);
        lbtn = findViewById(R.id.lbtn);

        Reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Name, Num;

                Name = name.getText().toString();
                Num = num.getText().toString();



                if (name.equals("")) ;
                {
                    Toast.makeText(Register.this, "name is blank", Toast.LENGTH_SHORT).show();
                }
                if (num.equals("")) ;
                {
                    Toast.makeText(Register.this, "name is blank", Toast.LENGTH_SHORT).show();
                }


            }


        });
        lbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent R =new Intent(Register.this,MainActivity.class);
                startActivity(R);
                finish();
            }
        });
    }
}